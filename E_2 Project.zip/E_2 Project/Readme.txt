A function generator is described that basically generates a
trapezoidal waveform whose leading and trailing ramps and
positive and negative plateaus can be varied in duration,
independently, between 0.5 ms and 50 s. By appropriate
interconnections between the constituent units of the generator, a
total of 12 different waveforms are generated, including triangular,
sinusoidal, square, rectangular, and sawtooth waveforms. The
output may be either free running or externally triggered to
produce an adjustable integral number of cycles.